<!DOCTYPE html>

<?php $path = url('/');?>


<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Plugins -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.13/datatables.min.css"/>
        <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.13/datatables.min.js"></script>

        <title>URLs</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #232b2f;
                font-family: 'Raleway', sans-serif;
                font-weight: bold;
                margin: 0;
            }
            a {
                color: #232b2f;
                text-decoration: none;
            }

            .content {
                width: 100%;
                padding-left: 30px;
                padding-right: 30px;
                max-width: 1200px;
                margin-left: auto;
                margin-right: auto;
                box-sizing: border-box;
                position: relative;
            }
            table {
                width: 100%;
                text-align: left;
                position: relative;
            }
            tr {
                margin: 0px;
            }
            a.short {
                color: #00f;
            }
            tr:nth-child(even) {
                background: #eee;
            }
            tr:nth-child(odd) {
                background: #e7e7e7;
            }
            td, th {
                padding-left: 5px;
                padding-right: 5px;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                max-width: 400px;
            }
        </style>
    </head>
    <body>
        @include('header')
        <div class="content">
            <h1>Lista de URLs:</h1>
            <table id="url-table" cellspacing=0>
                <thead>
                    <tr>
                        <th>url</th>
                        <th>short</th>
                        <th>criador</th>
                        <th>cliques</th>
                    </tr>
                </thead>
                <tbody>
                @foreach($lista_urls as $url)
                <tr>
                    <td>
                        {{$url->url}}
                    </td>
                    <td>
                        <a class="short" href="{{$path.'/'.$url->short}}">{{$path.'/'.$url->short}}</a>
                    </td>
                    <td>
                        <?php if ($url->criador == '') {
                            echo 'anônimo';
                        }
                        else {
                            echo $url->criador;
                        }
                        ?>
                    </td>
                    <td>
                        {{$url->cliques}}
                    </td>
                </tr>
                @endforeach
            </tbody>
            </table>
        </div>
        <script>
        (function($) {
        $(document).ready(function() {
            $('#url-table').DataTable( {
                "order": [[ 3, "desc" ]]
            } );
        } );
        })(jQuery);
        </script>
    </body>
</html>
