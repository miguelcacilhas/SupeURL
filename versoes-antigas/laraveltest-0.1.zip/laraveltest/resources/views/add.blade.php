<?php

$path = url('/');

if (isset($_GET['url'])) {
    $new_url = $_GET['url'];

    $duplicata = false;
    $matches = DB::table('urls')->where('url', $new_url)->get();
    foreach($matches as $match) {
        if ($match->url == $new_url) {
            $duplicata = true;
            $shortcode = $match->short;
        }
    }

    if ($duplicata == false) {
        $url_short_code = hash('crc32', $new_url);
        DB::table('urls')->insert(
            ['url' => $new_url, 'short' => $url_short_code]
        );
        $shortcode = $url_short_code;
    }
}

?>
<!DOCTYPE html>

<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>URLs</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #232b2f;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                margin: 0;
            }
            a {
                color: #232b2f;
                text-decoration: none;
            }

            .content {
                width: 100%;
                padding-left: 30px;
                padding-right: 30px;
                max-width: 1200px;
                margin-left: auto;
                margin-right: auto;
                box-sizing: border-box;
                position: relative;
            }
            .add-title {
                text-align: center;
            }
            form {
                text-align: center;
            }
            .add-input {
                text-align: left;
                width: 100%;
                max-width: 500px;
                height: 30px;
                padding: 3px 10px 3px 10px;
                box-sizing: border-box;
            }
            .add-submit {
                margin-top: 10px;
                width: 100%;
                max-width: 500px;
                height: 30px;
                box-sizing: border-box;
            }
            .align-center {
                text-align: center;
            }
        </style>
    </head>
    <body>
        @include('header')
        <div class="content">
            <?php if (isset($shortcode)) { ?>
                <h1 class="add-title">Aqui está sua URL encurtada:</h1>
                <div class="align-center">
                    <input class="add-input" onClick="this.select();" value="{{$path.'/'.$shortcode}}" />
                </div>
            <?php }
            else { ?>
            <h1 class="add-title">Adicione uma URL para encurtarmos:</h1>
        {!! Form::open(array('url' => 'add', 'method' => 'get')) !!}
            {{ Form::text('url', '', ['class' => 'add-input']) }}
            <br>
            {{ Form::submit('Cortar!', ['class' => 'add-submit']) }}
        {!! Form::close() !!}
        <?php } ?>
        </div>
    </body>
</html>
