<style>
.header {
    position: fixed;
    top: 0;
    left: 0;
    height: 80px;
    width: 100%;
    background-color: #ddd;
    z-index: 10;
}
.header-fill {
    height: 80px;
    width: 100%;
    position: relative;
}
.content {
    width: 100%;
    padding-left: 30px;
    padding-right: 30px;
    max-width: 1200px;
    margin-left: auto;
    margin-right: auto;
    box-sizing: border-box;
    position: relative;
}
.blue {
    color: #00f;
}
.page-title {
    font-family: 'Raleway', sans-serif;
    font-weight: 600;
}
.main-menu {
    list-style: none;
    display: inline-block;
    right: 30px;
    top: -5px;
    position: absolute;
    z-index: 10;
}
.menu-item {
    display: inline-block;
    margin-left: 30px;
    font-weight: bold;
}
.menu-item a {
    transition: color 0.5s ease;
    text-decoration: none;
}
.menu-item a:hover {
    color: #00f !important;
}
</style>
<header class="header">
    <div class="content">
        <h1 class="page-title">
            <span class="blue">Supe</span>U<span class="blue">R</span>L
        </h1>
        <ul class="main-menu">
            <li class="menu-item"><a href="{{url('/')}}">Home</a></li>
            <li class="menu-item"><a href="{{url('/urls/')}}">URLs</a></li>
            <li class="menu-item"><a href="{{url('/add/')}}">Adicionar</a></li>
            <li class="menu-item"><a>Login</a></li>
        </ul>
    </div>
</header>
<div class="header-fill">
</div>