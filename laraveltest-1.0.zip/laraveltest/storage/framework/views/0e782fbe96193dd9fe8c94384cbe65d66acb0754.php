<?php
if (isset($_GET['usuario']) && isset($_GET['senha'])) {
    $user = $_GET['usuario'];
    $pass = sha1($_GET['senha']); 
    $encontrado = false;
    $matches = DB::table('usuarios')->where('nome', $user)->get();
    foreach ($matches as $match) {
        $encontrado = true;
    }
    if ($encontrado != true) {
        $hashusr = hash('sha256', $user.$pass);
        DB::table('usuarios')->insert(
            ['nome' => $user, 'senha' => $pass, 'hash_unica' => $hashusr]
        );
        echo '<script>alert("usuário criado com sucesso, agora, realize o login.")</script>';
        echo '<script>window.location = "'.url('/login').'";</script>';
    }
    else {
        $erro = 'Nome já em uso!';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>URLs</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Raleway', sans-serif;
                font-weight: bold;
                margin: 0;
            }

            .content {
                width: 100%;
                padding-left: 30px;
                padding-right: 30px;
                max-width: 1200px;
                margin-left: auto;
                margin-right: auto;
                box-sizing: border-box;
            }
            a {
                color: #232b2f;
                text-decoration: none;
            }
            form {
                text-align: center;
            }
            .erro {
                color: #f00;
                text-align: center;
            }
            .add-input {
                text-align: left;
                width: 100%;
                max-width: 500px;
                height: 30px;
                padding: 3px 10px 3px 10px;
                box-sizing: border-box;
            }
            .add-submit {
                margin-top: 10px;
                width: 100%;
                max-width: 500px;
                height: 30px;
                box-sizing: border-box;
            }
            .title-middle {
                text-align: center;
            }
        </style>
    </head>
    <body>
        <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="content">
            <h1 class="title-middle">Registrar-se:</h1>
            <?php echo Form::open(array('url' => 'registro', 'method' => 'get')); ?>

            <?php echo e(Form::text('usuario', '', ['class' => 'add-input', 'placeholder' => 'Usuário', 'required' => 'required'])); ?>

            <br>
            <?php echo e(Form::password('senha', ['class' => 'add-input', 'placeholder' => 'Senha', 'required' => 'required'])); ?>

            <br>
            <?php echo e(Form::submit('Registrar-se', ['class' => 'add-submit'])); ?>

            <?php echo Form::close(); ?>

            <div class="erro">
                <?php if (isset($erro)) {
                    echo $erro;
                } ?>
            </div>
        </div>
    </body>
</html>
