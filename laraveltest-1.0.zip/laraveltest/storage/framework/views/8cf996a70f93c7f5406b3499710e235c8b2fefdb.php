<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>URLs</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                margin: 0;
            }

            .content {
                width: 100%;
                padding-left: 30px;
                padding-right: 30px;
                max-width: 1200px;
                margin-left: auto;
                margin-right: auto;
                box-sizing: border-box;
            }
            table {
                width: 100%;
                text-align: left;
                position: relative;
            }
            tr {
                margin: 0px;
            }
            tr:nth-child(even) {
                background: #eee;
            }
            tr:nth-child(odd) {
                background: #e7e7e7;
            }
            td, th {
                padding-left: 5px;
                padding-right: 5px;
            }
            a {
                color: #636b6f;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
            }
        </style>
    </head>
    <body>
        <div class="content">
            <h1>Lista de URLs:</h1>
            <table cellspacing=0>
                <tr>
                    <th>url</th>
                    <th>short</th>
                    <th>criador</th>
                    <th>cliques</th>
                </tr>
                <tr>
                    <?php $__currentLoopData = $lista_urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td>
                        <?php echo e($url->url); ?>

                    </td>
                    <td>
                        <?php $path = url('/url/'); ?>
                        <?php echo e($path.'/'.$url->short); ?>

                    </td>
                    <td>
                        <?php if ($url->criador == '') {
                            echo 'anônimo';
                        }
                        else {
                            echo $url->criador;
                        }
                        ?>
                    </td>
                    <td>
                        <?php echo e($url->cliques); ?>

                    </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </table>
        </div>
    </body>
</html>
