<!DOCTYPE html>

<?php $path = url('/');?>

<?php
if (isset($_GET['sair'])) {
    if ($_GET['sair'] == 'true') {
        setcookie('login_supeurl', 'deslogado', time() - 3600);
        echo '<script>window.location = "'.url("/").'";</script>';
    }
}
else { 
?>

<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Plugins -->
        <script type="text/javascript" src="<?php echo e(URL::asset('resources/assets/js/jquery.min.js')); ?>"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('resources/assets/css/datatables.min.css')); ?>">
        <script type="text/javascript" src="<?php echo e(URL::asset('resources/assets/js/dataTables.min.js')); ?>"></script>

        <title>URLs</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #232b2f;
                font-family: 'Raleway', sans-serif;
                font-weight: bold;
                margin: 0;
            }
            a {
                color: #232b2f;
                text-decoration: none;
            }

            .content {
                width: 100%;
                padding-left: 30px;
                padding-right: 30px;
                max-width: 1200px;
                margin-left: auto;
                margin-right: auto;
                box-sizing: border-box;
                position: relative;
            }
            table {
                width: 100%;
                text-align: left;
                position: relative;
            }
            tr {
                margin: 0px;
            }
            a.short {
                color: #00f;
            }
            tr:nth-child(even) {
                background: #eee;
            }
            tr:nth-child(odd) {
                background: #e7e7e7;
            }
            td, th {
                padding-left: 5px;
                padding-right: 5px;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                max-width: 400px;
            }
            .sair a {
                color: #f00;
            }
        </style>
    </head>
    <body>
        <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="content">
            <h1>Olá, <?php echo e($nome); ?>!</h1>
            <h2 class="sair"><a href="<?php echo e(url('/logado')); ?>?sair=true">Sair</a></h2>
            <h1>Suas URLs:</h1>
            <table id="url-table" cellspacing=0>
                <thead>
                    <tr>
                        <th>url</th>
                        <th>short</th>
                        <th>criador</th>
                        <th>cliques</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $lista_urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($url->url); ?>

                    </td>
                    <td>
                        <a class="short" href="<?php echo e($path.'/'.$url->short); ?>"><?php echo e($path.'/'.$url->short); ?></a>
                    </td>
                    <td>
                        <?php if ($url->criador == '') {
                            echo 'anônimo';
                        }
                        else {
                            echo $url->criador;
                        }
                        ?>
                    </td>
                    <td>
                        <?php echo e($url->cliques); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>
        </div>
        <script>
        (function($) {
        $(document).ready(function() {
            $('#url-table').DataTable( {
                "order": [[ 3, "desc" ]]
            } );
        } );
        })(jQuery);
        </script>
    </body>
</html>

<?php
}
?>