<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', function () {
    return view('welcome');
});
Route::get('/header', function() {
	return view('header');
});
Route::get('/login', function() {
	return view('login');
});
Route::get('/registro', function() {
	return view('registro');
});
Route::get('/add', function() {
	return view('add');
});
Route::get('/urls', function () {

	$lista_urls = DB::table('urls')->get();

    return view('urls', compact('lista_urls'));
});
Route::get('/logado', function() {
	
	if (isset($_COOKIE['login_supeurl'])) {
		$hash = $_COOKIE['login_supeurl'];
		$matches = DB::table('usuarios')->where('hash_unica', $hash)->get();
	    foreach ($matches as $match) {
	        $nome = $match->nome;
	    }

		$lista_urls = DB::table('urls')->where('criador', $nome)->get();

    	return view('logado', compact('lista_urls', 'nome'));
	}
	else {
		return view('logado');
	}
});
Route::get('/{url}', function ($url) {

	//$destiny = DB::table('urls')->find($url);
	$destiny = DB::table('urls')->where('short', '=', $url)->get();
	DB::table('urls')->where('short', '=', $url)->increment('cliques', 1);

    return view('welcome', compact('destiny'));
});